import React, { useState, useEffect, useRef } from "react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from "recharts";
import {
  Brain, Zap, Target, Activity, FileText, Filter, Tag, AlertTriangle,
  Clock, CheckCircle, ArrowRight, Menu, X, ChevronDown,
  Database, Cpu, Hash, Layers, Send, TrendingUp, Shield,
} from "lucide-react";

// ─── Hooks ────────────────────────────────────────────────────────────────────

function useInView(threshold = 0.15) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setInView(true); observer.disconnect(); } },
      { threshold }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);
  return { ref, inView };
}

function useCountUp(target: number, decimals: number, inView: boolean, duration = 1800) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (!inView) return;
    const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setValue(parseFloat((eased * target).toFixed(decimals)));
      if (p < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [inView, target, decimals, duration]);
  return value;
}

// ─── Data ─────────────────────────────────────────────────────────────────────

const pipelineSteps = [
  { icon: FileText, label: "Raw Ticket Text",       desc: "Customer-submitted support requests in natural language",           accent: "#4776f3" },
  { icon: Filter,   label: "Text Cleaning",          desc: "Remove HTML, special characters, and normalize whitespace",         accent: "#5b7ff5" },
  { icon: Hash,     label: "Tokenization",           desc: "Split text into meaningful tokens and subword units",               accent: "#6f88f7" },
  { icon: Layers,   label: "Stopword Removal",       desc: "Filter common words that carry no predictive signal",               accent: "#8b72f3" },
  { icon: Database, label: "TF-IDF Vectorization",   desc: "Convert tokens into weighted numerical feature vectors",            accent: "#9060ef" },
  { icon: Cpu,      label: "Model Training",         desc: "Train multi-output classifier on 3 200 labeled tickets",           accent: "#8b5cf6" },
  { icon: Tag,      label: "Category Prediction",    desc: "Assign ticket to Account, Billing, Technical, or General",         accent: "#7c3aed" },
  { icon: AlertTriangle, label: "Priority Prediction", desc: "Score urgency: High · Medium · Low — routed to the right queue", accent: "#6d28d9" },
];

const metricDefs = [
  { label: "Accuracy",  value: 96.4, suffix: "%", decimals: 1, icon: Target,      grad: "from-blue-500 to-blue-700"    },
  { label: "Precision", value: 95.8, suffix: "%", decimals: 1, icon: CheckCircle, grad: "from-violet-500 to-violet-700" },
  { label: "Recall",    value: 95.2, suffix: "%", decimals: 1, icon: Activity,    grad: "from-purple-500 to-purple-700" },
  { label: "F1 Score",  value: 95.5, suffix: "%", decimals: 1, icon: TrendingUp,  grad: "from-fuchsia-500 to-fuchsia-700" },
];

const classData = [
  { cat: "Account",   precision: 97, recall: 96, f1: 96.5 },
  { cat: "Billing",   precision: 95, recall: 94, f1: 94.5 },
  { cat: "Technical", precision: 96, recall: 97, f1: 96.5 },
  { cat: "General",   precision: 95, recall: 94, f1: 94.5 },
];

const confMatrix = [
  [142, 3,   2,   1  ],
  [4,   138, 2,   2  ],
  [2,   1,   156, 3  ],
  [3,   2,   4,   145],
];
const confLabels = ["Account", "Billing", "Technical", "General"];

function classifyTicket(text: string) {
  const t = text.toLowerCase();
  if (/password|account|login|sign.?in|access|locked|credential|username|2fa|authenticat/.test(t))
    return { category: "Account Issue",     priority: "High",   conf: 97 };
  if (/billing|charge|payment|invoice|refund|subscription|fee|overcharg/.test(t))
    return { category: "Billing Issue",     priority: "High",   conf: 94 };
  if (/crash|error|bug|slow|not working|broken|fail|cannot load|timeout|glitch/.test(t))
    return { category: "Technical Support", priority: "Medium", conf: 95 };
  return   { category: "General Inquiry",   priority: "Low",    conf: 91 };
}

const priorityCls = (p: string) =>
  p === "High"   ? "text-red-400   bg-red-400/10   border-red-400/30" :
  p === "Medium" ? "text-amber-400 bg-amber-400/10 border-amber-400/30" :
                   "text-emerald-400 bg-emerald-400/10 border-emerald-400/30";

// ─── Shared primitives ────────────────────────────────────────────────────────

function Pill({ children }: { children: React.ReactNode }) {
  return (
    <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-mono font-medium"
      style={{ background: "rgba(71,118,243,0.1)", border: "1px solid rgba(71,118,243,0.25)", color: "#93bbff" }}>
      {children}
    </div>
  );
}

function Glass({ children, className = "", style = {} }: { children: React.ReactNode; className?: string; style?: React.CSSProperties }) {
  return (
    <div className={`rounded-2xl ${className}`}
      style={{ background: "rgba(13,22,48,0.75)", border: "1px solid rgba(255,255,255,0.07)", backdropFilter: "blur(20px)", ...style }}>
      {children}
    </div>
  );
}

// ─── Hero dashboard illustration ──────────────────────────────────────────────

function HeroDashboard() {
  const [active, setActive] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setActive((a) => (a + 1) % 5), 2200);
    return () => clearInterval(id);
  }, []);

  const tickets = [
    { id: "TK-2847", text: "Cannot login with new password",    cat: "Account",   pri: "High",   priC: "#ef4444" },
    { id: "TK-2848", text: "Double charge on invoice #9812",    cat: "Billing",   pri: "High",   priC: "#ef4444" },
    { id: "TK-2849", text: "App crashes on startup (iOS 17)",   cat: "Technical", pri: "Medium", priC: "#f59e0b" },
    { id: "TK-2850", text: "How do I export my data to CSV?",   cat: "General",   pri: "Low",    priC: "#10b981" },
    { id: "TK-2851", text: "Reset 2FA — phone number changed",  cat: "Account",   pri: "High",   priC: "#ef4444" },
  ];

  return (
    <div className="relative select-none">
      <Glass className="p-6 shadow-2xl">
        {/* header */}
        <div className="flex items-center justify-between mb-5">
          <div>
            <p className="text-sm font-semibold text-white">Support Queue</p>
            <p className="text-xs font-mono mt-0.5" style={{ color: "#64748b" }}>AI Classification · Live</p>
          </div>
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-mono"
            style={{ background: "rgba(16,185,129,0.1)", border: "1px solid rgba(16,185,129,0.3)", color: "#6ee7b7" }}>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse inline-block" />
            Active
          </div>
        </div>

        {/* ticket rows */}
        <div className="space-y-2">
          {tickets.map((tk, i) => {
            const isActive = active === i;
            return (
              <div key={tk.id} className="flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-500"
                style={{
                  background: isActive ? "rgba(71,118,243,0.1)" : "rgba(255,255,255,0.03)",
                  border: `1px solid ${isActive ? "rgba(71,118,243,0.35)" : "rgba(255,255,255,0.05)"}`,
                }}>
                <span className="text-xs font-mono flex-shrink-0" style={{ color: "#475569", width: "3.5rem" }}>{tk.id}</span>
                <span className="flex-1 text-xs truncate" style={{ color: "#94a3b8" }}>{tk.text}</span>
                {isActive ? (
                  <span className="text-xs font-mono flex-shrink-0 flex items-center gap-1.5" style={{ color: "#60a5fa" }}>
                    <span className="w-1 h-1 rounded-full bg-blue-400 animate-pulse inline-block" />
                    analyzing
                  </span>
                ) : (
                  <span className="flex items-center gap-2 flex-shrink-0">
                    <span className="text-xs font-mono" style={{ color: "#64748b" }}>{tk.cat}</span>
                    <span className="text-xs font-mono font-bold" style={{ color: tk.priC }}>{tk.pri}</span>
                  </span>
                )}
              </div>
            );
          })}
        </div>

        {/* stats strip */}
        <div className="mt-5 pt-4 grid grid-cols-3 gap-2" style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}>
          {[["142", "Tickets Today"], ["96.4%", "Accuracy"], ["1.2 s", "Avg. Classify"]].map(([v, l]) => (
            <div key={l} className="text-center">
              <p className="text-sm font-bold text-white font-mono">{v}</p>
              <p className="text-xs mt-0.5" style={{ color: "#475569" }}>{l}</p>
            </div>
          ))}
        </div>
      </Glass>

      {/* floating badge */}
      <div className="absolute -bottom-4 -left-4 px-3.5 py-2 rounded-xl shadow-xl"
        style={{ background: "rgba(124,58,237,0.18)", border: "1px solid rgba(124,58,237,0.45)", backdropFilter: "blur(20px)" }}>
        <div className="flex items-center gap-2">
          <Brain className="w-4 h-4" style={{ color: "#c4b5fd" }} />
          <span className="text-xs font-semibold" style={{ color: "#c4b5fd" }}>NLP Model v2.3</span>
        </div>
      </div>

      {/* floating accent */}
      <div className="absolute -top-3 -right-3 px-3 py-1.5 rounded-lg shadow-lg"
        style={{ background: "rgba(71,118,243,0.15)", border: "1px solid rgba(71,118,243,0.4)", backdropFilter: "blur(20px)" }}>
        <span className="text-xs font-mono font-medium" style={{ color: "#93bbff" }}>TF-IDF · SVM</span>
      </div>
    </div>
  );
}

// ─── Metric card ──────────────────────────────────────────────────────────────

function MetricCard({ def, inView }: { def: typeof metricDefs[0]; inView: boolean }) {
  const count = useCountUp(def.value, def.decimals, inView);
  const Icon = def.icon;
  return (
    <div className="relative rounded-2xl p-px overflow-hidden transition-transform duration-300 hover:-translate-y-1"
      style={{ background: "linear-gradient(135deg, rgba(71,118,243,0.4), rgba(124,58,237,0.4))" }}>
      <div className="rounded-2xl p-6 h-full" style={{ background: "rgba(10,18,40,0.95)" }}>
        <div className={`inline-flex p-2.5 rounded-xl bg-gradient-to-br ${def.grad} mb-4`}>
          <Icon className="w-4 h-4 text-white" />
        </div>
        <p className="text-3xl font-bold text-white font-mono tracking-tight mb-1">
          {count.toFixed(def.decimals)}{def.suffix}
        </p>
        <p className="text-xs font-medium" style={{ color: "#64748b" }}>{def.label}</p>
      </div>
    </div>
  );
}

// ─── Confusion matrix ─────────────────────────────────────────────────────────

function ConfusionMatrix() {
  const max = Math.max(...confMatrix.flat());
  return (
    <div className="overflow-auto">
      <div style={{ minWidth: 280 }}>
        {/* column headers */}
        <div className="flex mb-1 ml-20">
          {confLabels.map((l) => (
            <div key={l} className="flex-1 text-center text-xs font-mono px-0.5 truncate" style={{ color: "#475569" }}>
              {l.slice(0, 4)}
            </div>
          ))}
        </div>
        {/* rows */}
        {confMatrix.map((row, i) => (
          <div key={i} className="flex items-center mb-1">
            <div className="flex-shrink-0 text-right text-xs font-mono pr-2 truncate" style={{ width: "5rem", color: "#475569" }}>
              {confLabels[i].slice(0, 4)}
            </div>
            {row.map((val, j) => {
              const intensity = val / max;
              const correct = i === j;
              const bg = correct
                ? `rgba(71,118,243,${0.12 + intensity * 0.72})`
                : `rgba(124,58,237,${intensity * 0.45})`;
              return (
                <div key={j} className="flex-1 m-0.5 rounded-lg flex items-center justify-center text-xs font-mono font-bold transition-transform duration-200 hover:scale-110"
                  style={{ background: bg, color: intensity > 0.25 ? "#e2e8f7" : "#475569", height: 44, minWidth: 40 }}>
                  {val}
                </div>
              );
            })}
          </div>
        ))}
        {/* legend */}
        <div className="flex gap-5 mt-4 ml-20">
          {[["rgba(71,118,243,0.75)", "Correct"], ["rgba(124,58,237,0.35)", "Misclassified"]].map(([c, l]) => (
            <div key={l} className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm flex-shrink-0" style={{ background: c }} />
              <span className="text-xs font-mono" style={{ color: "#475569" }}>{l}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Custom tooltip ───────────────────────────────────────────────────────────

const ChartTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-xl p-3 shadow-2xl" style={{ background: "#0d1630", border: "1px solid rgba(255,255,255,0.1)" }}>
      <p className="text-xs font-mono mb-2" style={{ color: "#64748b" }}>{label}</p>
      {payload.map((p: any) => (
        <p key={p.dataKey} className="text-xs font-mono font-bold" style={{ color: p.fill }}>
          {p.name}: {p.value}%
        </p>
      ))}
    </div>
  );
};

// ─── Main component ───────────────────────────────────────────────────────────

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [demoText, setDemoText] = useState("Unable to access my account after password reset.");
  const [prediction, setPrediction] = useState<{ category: string; priority: string; conf: number } | null>(null);
  const [predicting, setPredicting] = useState(false);

  const aboutRef   = useInView();
  const pipeRef    = useInView();
  const metricsRef = useInView();
  const demoRef    = useInView();

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);

  const handlePredict = () => {
    if (!demoText.trim() || predicting) return;
    setPredicting(true);
    setPrediction(null);
    setTimeout(() => { setPrediction(classifyTicket(demoText)); setPredicting(false); }, 1300);
  };

  const navLinks = [
    { label: "About",    href: "#about"    },
    { label: "Pipeline", href: "#pipeline" },
    { label: "Results",  href: "#results"  },
    { label: "Demo",     href: "#demo"     },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>

      {/* ── NAV ── */}
      <nav className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
        style={{
          background: scrolled ? "rgba(6,11,24,0.88)" : "transparent",
          backdropFilter: scrolled ? "blur(20px)" : "none",
          borderBottom: scrolled ? "1px solid rgba(255,255,255,0.07)" : "1px solid transparent",
        }}>
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg" style={{ background: "linear-gradient(135deg, #4776f3, #7c3aed)" }}>
              <Brain className="w-4 h-4 text-white" />
            </div>
            <span className="font-bold text-sm tracking-tight text-white">TicketAI</span>
          </div>

          <div className="hidden md:flex items-center gap-8">
            {navLinks.map(({ label, href }) => (
              <a key={label} href={href}
                className="text-sm font-medium transition-colors duration-200 hover:text-white"
                style={{ color: "#64748b" }}>
                {label}
              </a>
            ))}
          </div>

          <a href="#demo" className="hidden md:inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-semibold text-white transition-all duration-200 hover:opacity-90"
            style={{ background: "linear-gradient(135deg, #4776f3, #7c3aed)" }}>
            Try Demo <ArrowRight className="w-3.5 h-3.5" />
          </a>

          <button className="md:hidden text-slate-400 hover:text-white" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {menuOpen && (
          <div className="md:hidden px-6 py-5 flex flex-col gap-5"
            style={{ background: "rgba(6,11,24,0.97)", borderTop: "1px solid rgba(255,255,255,0.07)" }}>
            {navLinks.map(({ label, href }) => (
              <a key={label} href={href} className="text-sm font-medium text-slate-300 hover:text-white transition-colors"
                onClick={() => setMenuOpen(false)}>
                {label}
              </a>
            ))}
          </div>
        )}
      </nav>

      {/* ── HERO ── */}
      <section className="relative min-h-screen flex items-center overflow-hidden pt-16">
        {/* mesh background */}
        <div className="absolute inset-0 pointer-events-none" aria-hidden>
          <div className="absolute inset-0" style={{
            background: "radial-gradient(ellipse 90% 60% at 50% -5%, rgba(71,118,243,0.22) 0%, transparent 60%), radial-gradient(ellipse 55% 45% at 85% 85%, rgba(124,58,237,0.18) 0%, transparent 55%)",
          }} />
          <div className="absolute inset-0" style={{
            backgroundImage: "linear-gradient(rgba(255,255,255,0.025) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.025) 1px, transparent 1px)",
            backgroundSize: "64px 64px",
          }} />
        </div>

        <div className="relative max-w-7xl mx-auto px-6 py-28 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center w-full">
          {/* copy */}
          <div>
            <Pill>
              <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse inline-block" />
              NLP · Classification · Prioritization
            </Pill>

            <h1 className="mt-6 text-5xl lg:text-[3.5rem] font-extrabold text-white leading-[1.08] tracking-tight mb-6">
              AI-Powered Support{" "}
              <span className="block" style={{ background: "linear-gradient(130deg, #60a5fa, #a78bfa)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
                Ticket Intelligence
              </span>
            </h1>

            <p className="text-lg leading-relaxed mb-10 max-w-lg" style={{ color: "#94a3b8" }}>
              Automatically categorize customer support tickets and predict urgency
              using Machine Learning and NLP — so your team focuses on what matters most.
            </p>

            <div className="flex flex-wrap gap-4">
              <a href="#demo"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold text-sm text-white transition-all duration-200 hover:opacity-90 hover:-translate-y-px"
                style={{ background: "linear-gradient(135deg, #4776f3, #7c3aed)" }}>
                Try the Live Demo <ArrowRight className="w-4 h-4" />
              </a>
              <a href="#pipeline"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl font-semibold text-sm transition-all duration-200 hover:text-white"
                style={{ border: "1px solid rgba(255,255,255,0.14)", color: "#94a3b8" }}>
                View Pipeline <ChevronDown className="w-4 h-4" />
              </a>
            </div>

            {/* stat strip */}
            <div className="flex flex-wrap gap-8 mt-12 pt-10" style={{ borderTop: "1px solid rgba(255,255,255,0.07)" }}>
              {[["96.4%", "Test Accuracy"], ["4 Classes", "Ticket Categories"], ["3 Levels", "Priority Grades"]].map(([v, l]) => (
                <div key={l}>
                  <p className="text-2xl font-bold text-white font-mono">{v}</p>
                  <p className="text-xs mt-0.5" style={{ color: "#475569" }}>{l}</p>
                </div>
              ))}
            </div>
          </div>

          {/* illustration */}
          <div className="hidden lg:block">
            <HeroDashboard />
          </div>
        </div>

        {/* scroll cue */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce">
          <ChevronDown className="w-4 h-4" style={{ color: "#334155" }} />
        </div>
      </section>

      {/* ── ABOUT ── */}
      <section id="about" className="py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div ref={aboutRef.ref}
            className={`transition-all duration-700 ${aboutRef.inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
            <Pill>About the Project</Pill>
            <h2 className="mt-4 text-4xl font-bold text-white tracking-tight mb-3">
              Smarter Support, Powered by NLP
            </h2>
            <p className="text-lg mb-12 max-w-2xl" style={{ color: "#94a3b8" }}>
              This ML solution automates ticket triage — cutting response times, reducing manual sorting,
              and surfacing critical issues before they escalate.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {[
                { icon: FileText,      title: "Reads Descriptions",    desc: "Analyzes raw text from incoming support requests with full NLP preprocessing.",                       borderC: "rgba(71,118,243,0.25)",  bgC: "rgba(71,118,243,0.07)",  iconC: "#60a5fa" },
                { icon: Tag,           title: "Classifies Categories", desc: "Maps each ticket to Account, Billing, Technical, or General Inquiry in milliseconds.",                borderC: "rgba(124,58,237,0.25)", bgC: "rgba(124,58,237,0.07)", iconC: "#a78bfa" },
                { icon: AlertTriangle, title: "Predicts Priority",     desc: "Scores urgency as High, Medium, or Low to guide queue ordering and SLA compliance.",                  borderC: "rgba(167,139,250,0.25)", bgC: "rgba(167,139,250,0.07)", iconC: "#c4b5fd" },
                { icon: Clock,         title: "Faster Response",       desc: "Helps support teams identify critical issues first, improving CSAT and resolution speed.",            borderC: "rgba(59,130,246,0.25)",  bgC: "rgba(59,130,246,0.07)",  iconC: "#93c5fd" },
              ].map((card, i) => {
                const Icon = card.icon;
                return (
                  <div key={card.title}
                    className={`rounded-2xl p-6 transition-all duration-500 hover:-translate-y-1.5 ${aboutRef.inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
                    style={{ background: card.bgC, border: `1px solid ${card.borderC}`, transitionDelay: `${i * 90}ms` }}>
                    <Icon className="w-5 h-5 mb-4" style={{ color: card.iconC }} />
                    <h3 className="font-semibold text-white mb-2 text-sm">{card.title}</h3>
                    <p className="text-xs leading-relaxed" style={{ color: "#64748b" }}>{card.desc}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* ── PIPELINE ── */}
      <section id="pipeline" className="py-24"
        style={{ background: "linear-gradient(180deg, transparent, rgba(71,118,243,0.04) 50%, transparent)" }}>
        <div className="max-w-7xl mx-auto px-6">
          <div ref={pipeRef.ref}
            className={`transition-all duration-700 ${pipeRef.inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
            <Pill>ML Pipeline</Pill>
            <h2 className="mt-4 text-4xl font-bold text-white tracking-tight mb-3">
              From Raw Text to Prediction
            </h2>
            <p className="text-lg mb-14 max-w-2xl" style={{ color: "#94a3b8" }}>
              Eight sequential stages transform unstructured ticket descriptions into precise, actionable predictions.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {pipelineSteps.map((step, i) => {
                const Icon = step.icon;
                return (
                  <div key={step.label}
                    className={`group relative rounded-2xl p-5 transition-all duration-500 hover:-translate-y-1.5 cursor-default ${pipeRef.inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
                    style={{
                      background: "rgba(13,22,48,0.65)",
                      border: "1px solid rgba(255,255,255,0.07)",
                      backdropFilter: "blur(12px)",
                      transitionDelay: `${i * 80}ms`,
                    }}>
                    {/* step number + icon */}
                    <div className="flex items-center gap-2.5 mb-3.5">
                      <div className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-mono font-bold flex-shrink-0"
                        style={{ background: `${step.accent}22`, border: `1px solid ${step.accent}55`, color: step.accent }}>
                        {String(i + 1).padStart(2, "0")}
                      </div>
                      <Icon className="w-4 h-4 flex-shrink-0" style={{ color: step.accent }} />
                    </div>
                    <h4 className="font-semibold text-white text-sm mb-1.5">{step.label}</h4>
                    <p className="text-xs leading-relaxed" style={{ color: "#475569" }}>{step.desc}</p>

                    {/* arrow connector — visible on lg only */}
                    {i < pipelineSteps.length - 1 && i % 4 !== 3 && (
                      <div className="hidden lg:flex absolute top-1/2 -right-2 z-10 -translate-y-1/2">
                        <ArrowRight className="w-4 h-4" style={{ color: "rgba(71,118,243,0.4)" }} />
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* ── RESULTS ── */}
      <section id="results" className="py-24">
        <div className="max-w-7xl mx-auto px-6">
          <div ref={metricsRef.ref}
            className={`transition-all duration-700 ${metricsRef.inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
            <Pill>Results & Evaluation</Pill>
            <h2 className="mt-4 text-4xl font-bold text-white tracking-tight mb-3">
              High-Performance Classification
            </h2>
            <p className="text-lg mb-12 max-w-2xl" style={{ color: "#94a3b8" }}>
              Validated on a held-out test set of 600 support tickets across all category and priority combinations.
            </p>

            {/* metric cards */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
              {metricDefs.map((m, i) => (
                <div key={m.label}
                  className={`transition-all duration-700 ${metricsRef.inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
                  style={{ transitionDelay: `${i * 80}ms` }}>
                  <MetricCard def={m} inView={metricsRef.inView} />
                </div>
              ))}
            </div>

            {/* charts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              {/* Classification report */}
              <Glass className={`p-6 transition-all duration-700 ${metricsRef.inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
                style={{ transitionDelay: "320ms" } as React.CSSProperties}>
                <h3 className="text-white font-semibold mb-0.5">Classification Report</h3>
                <p className="text-xs font-mono mb-6" style={{ color: "#475569" }}>Precision · Recall · F1 per category</p>
                <ResponsiveContainer width="100%" height={210}>
                  <BarChart data={classData} barGap={3} barCategoryGap="28%">
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" vertical={false} />
                    <XAxis dataKey="cat" tick={{ fill: "#475569", fontSize: 11, fontFamily: "JetBrains Mono, monospace" }} axisLine={false} tickLine={false} />
                    <YAxis domain={[88, 100]} tick={{ fill: "#475569", fontSize: 11, fontFamily: "JetBrains Mono, monospace" }} axisLine={false} tickLine={false} />
                    <Tooltip content={<ChartTooltip />} />
                    <Bar dataKey="precision" name="Precision" fill="#4776f3" radius={[5, 5, 0, 0]} />
                    <Bar dataKey="recall"    name="Recall"    fill="#7c3aed" radius={[5, 5, 0, 0]} />
                    <Bar dataKey="f1"        name="F1"        fill="#a78bfa" radius={[5, 5, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
                <div className="flex gap-5 mt-3">
                  {[["#4776f3", "Precision"], ["#7c3aed", "Recall"], ["#a78bfa", "F1 Score"]].map(([c, l]) => (
                    <div key={l} className="flex items-center gap-1.5">
                      <div className="w-2.5 h-2.5 rounded-sm flex-shrink-0" style={{ background: c }} />
                      <span className="text-xs font-mono" style={{ color: "#475569" }}>{l}</span>
                    </div>
                  ))}
                </div>
              </Glass>

              {/* Confusion matrix */}
              <Glass className={`p-6 transition-all duration-700 ${metricsRef.inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
                style={{ transitionDelay: "420ms" } as React.CSSProperties}>
                <h3 className="text-white font-semibold mb-0.5">Confusion Matrix</h3>
                <p className="text-xs font-mono mb-5" style={{ color: "#475569" }}>Predicted vs. actual class distribution</p>
                <ConfusionMatrix />
              </Glass>
            </div>
          </div>
        </div>
      </section>

      {/* ── DEMO ── */}
      <section id="demo" className="py-24"
        style={{ background: "linear-gradient(180deg, transparent, rgba(124,58,237,0.05) 50%, transparent)" }}>
        <div className="max-w-3xl mx-auto px-6">
          <div ref={demoRef.ref}
            className={`text-center mb-10 transition-all duration-700 ${demoRef.inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
            <Pill>Live Demo</Pill>
            <h2 className="mt-4 text-4xl font-bold text-white tracking-tight mb-3">Try the Classifier</h2>
            <p className="text-lg" style={{ color: "#94a3b8" }}>
              Enter a support ticket and see the model predict category and priority in real time.
            </p>
          </div>

          <Glass className={`p-8 transition-all duration-700 ${demoRef.inView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
            style={{ transitionDelay: "100ms" } as React.CSSProperties}>
            <label className="block text-sm font-medium text-slate-300 mb-2.5">Ticket Description</label>

            <textarea
              value={demoText}
              onChange={(e) => { setDemoText(e.target.value); setPrediction(null); }}
              rows={4}
              placeholder="Describe the support issue…"
              className="w-full rounded-xl px-4 py-3 text-sm resize-none outline-none transition-colors duration-200 text-slate-200 placeholder-slate-600"
              style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", fontFamily: "inherit" }}
              onFocus={(e) => (e.currentTarget.style.borderColor = "rgba(71,118,243,0.5)")}
              onBlur={(e)  => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
            />

            {/* quick examples */}
            <div className="flex flex-wrap gap-2 mt-3 mb-6 items-center">
              <span className="text-xs font-mono" style={{ color: "#334155" }}>try:</span>
              {[
                "Unable to access my account after password reset.",
                "I was charged twice for my subscription this month.",
                "The app keeps crashing on iOS 17 after the update.",
              ].map((ex) => (
                <button key={ex}
                  onClick={() => { setDemoText(ex); setPrediction(null); }}
                  className="text-xs px-3 py-1.5 rounded-lg transition-all duration-200 hover:border-blue-500/40 hover:text-blue-400"
                  style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", color: "#475569" }}>
                  {ex.length > 38 ? ex.slice(0, 38) + "…" : ex}
                </button>
              ))}
            </div>

            <button
              onClick={handlePredict}
              disabled={predicting || !demoText.trim()}
              className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl font-semibold text-sm text-white transition-all duration-200 hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed"
              style={{ background: "linear-gradient(135deg, #4776f3, #7c3aed)" }}>
              {predicting
                ? <><span className="w-4 h-4 rounded-full border-2 border-white/30 border-t-white animate-spin" />Analyzing ticket…</>
                : <><Send className="w-4 h-4" />Classify Ticket</>}
            </button>

            {prediction && (
              <div className="mt-6 rounded-2xl p-6"
                style={{ background: "rgba(71,118,243,0.07)", border: "1px solid rgba(71,118,243,0.22)", animation: "fadeUp 0.35s ease" }}>
                <div className="flex items-center gap-2 mb-5">
                  <CheckCircle className="w-4 h-4" style={{ color: "#60a5fa" }} />
                  <span className="text-sm font-medium" style={{ color: "#60a5fa" }}>Prediction Complete</span>
                  <span className="ml-auto text-xs font-mono" style={{ color: "#475569" }}>{prediction.conf}% confidence</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="rounded-xl p-4" style={{ background: "rgba(255,255,255,0.04)" }}>
                    <p className="text-xs font-mono uppercase tracking-wider mb-2" style={{ color: "#475569" }}>Category</p>
                    <div className="flex items-center gap-2">
                      <Tag className="w-4 h-4" style={{ color: "#60a5fa" }} />
                      <span className="text-white font-semibold text-sm">{prediction.category}</span>
                    </div>
                  </div>
                  <div className="rounded-xl p-4" style={{ background: "rgba(255,255,255,0.04)" }}>
                    <p className="text-xs font-mono uppercase tracking-wider mb-2" style={{ color: "#475569" }}>Priority Level</p>
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border text-xs font-semibold font-mono ${priorityCls(prediction.priority)}`}>
                      <AlertTriangle className="w-3.5 h-3.5" />
                      {prediction.priority} Priority
                    </span>
                  </div>
                </div>
              </div>
            )}
          </Glass>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer className="py-8" style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}>
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg" style={{ background: "linear-gradient(135deg, #4776f3, #7c3aed)" }}>
              <Brain className="w-4 h-4 text-white" />
            </div>
            <span className="text-sm font-bold text-white">TicketAI</span>
          </div>
          <p className="text-sm font-mono" style={{ color: "#334155" }}>
            © 2026 Support Ticket Classification & Prioritization Project
          </p>
          <div className="flex items-center gap-2 text-xs font-mono" style={{ color: "#334155" }}>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
            Model v2.3 · Accuracy 96.4%
          </div>
        </div>
      </footer>

      <style>{`
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(12px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>
    </div>
  );
}
